import reflex as rx

config = rx.Config(
    app_name="reflex_test",
)